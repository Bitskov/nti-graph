# pyroutelib2

Github version of http://svn.openstreetmap.org/applications/routing/pyroutelib2/

## TODO:
- Test all python 2&3 compatibility
- Test all functionality. Currently route.py runs, as does LoadOSM (using osmapi).

## Done
- Fixed reading of Open Street Map's .osm file.
- Added [metaodi/osmapi](https://github.com/metaodi/osmapi) to pull OSM data automatically
